run("cp /tmp/rat/rat.py /py/rat.py")
